import React from 'react'
import { useState } from 'react'
import { ClipLoader } from 'react-spinners';

export const Contact = () => {
  const [name , setName] = useState("");
  const[email , setEmail] = useState("");
  const [message , setMessage] = useState("");
  const[loading , setLoading] = useState(false);
  return (
    <section className='contact'>
  <form>
    <h1> CONTACT US</h1>
    <div>
      <lable>Name</lable>
      <input type='text' value={name} onChange={(e) => setName(e.target.value)}  />
    </div>
    <div>
      <lable>Email</lable>
      <input type='email' value={email} onChange={(e) => setEmail(e.target.value)}  />
    </div> 
    <div>
      <lable>Message</lable>
      <input type='text' value={message} onChange={(e) => setMessage(e.target.value)} />
    </div>
    <button type='submit' disabled={loading ==true} style = {{display : "flex" , justifyContent :"center " , alignItems: "center", gap:"15px"}}>
    {loading && <ClipLoader size={20} color='white'/>}
      Send Message
    </button>
  </form>
    </section>
  )
}
