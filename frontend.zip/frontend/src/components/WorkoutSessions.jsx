import React from 'react'

export const WorkoutSessions = () => {
  return (
   <section className='workout_session'>
  <div className='wrapper'> 
    <h1> Personalized workout sessions </h1>
    <p>
    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
    </p>
    <img src='/img5.jpg' alt='workout'/>
  </div>
  <div className='wrapper'>
    <h1>
      FEATURED BOOTCAMPS
    </h1>
    <p>
    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
    </p>
    <div className='bootcamps'>
      <div>
       <h4>
        this is a demo boot camp session for further details
       </h4>
       <p>
        the bootcamps are the ones that you come and experience how our trainers train you and how good the training and workout sessions are going to
       </p>
      </div>
      <div>
       <h4>
        this is a demo boot camp session for further details
       </h4>
       <p>
        the bootcamps are the ones that you come and experience how our trainers train you and how good the training and workout sessions are going to
       </p>
      </div>
      <div>
       <h4>
        this is a demo boot camp session for further details
       </h4>
       <p>
        the bootcamps are the ones that you come and experience how our trainers train you and how good the training and workout sessions are going to
       </p>
      </div>
      <div>
       <h4>
        this is a demo boot camp session for further details
       </h4>
       <p>
        the bootcamps are the ones that you come and experience how our trainers train you and how good the training and workout sessions are going to
       </p>
      </div>
    </div>
  </div>
   </section>
  )
}
