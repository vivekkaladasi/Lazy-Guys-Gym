import React from 'react'

const Footer = () => {
  return (
    <footer>
      Designed And Developed By Vivek Kaladasi
    </footer>
  )
}

export default Footer