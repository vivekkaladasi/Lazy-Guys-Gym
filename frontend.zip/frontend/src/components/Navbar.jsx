import React from 'react'

export const Navbar = () => {
  return (
    <header>
       <p> LAZY GUYS GYM</p> 
    </header>
  )
}
