import React from "react";

  export const Hero = () => {
  return(
  <section className='hero'>
    <div className="content">
      <div className="title">
        <h1>LET'S</h1>
        <h1>PROVE THEM</h1>
        <h1>WRONG</h1>
      </div>
      <div className="sub-title">
        <p>Your Journey Through Discipline Starts Here</p>
        <p>Unleash Your Potential</p>
      </div>
      <div className="buttons">
        <button>
        start Your Journey
        </button>   
        <button>
        Discover Your Plan
        </button>
      </div>
    </div>
  </section>
)};
